<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Testi Edit</h3>
            </div>
			<?php echo form_open('testi/edit/'.$testi['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="nama" class="control-label"><span class="text-danger">*</span>Nama</label>
						<div class="form-group">
							<input type="text" name="nama" value="<?php echo ($this->input->post('nama') ? $this->input->post('nama') : $testi['nama']); ?>" class="form-control" id="nama" />
							<span class="text-danger"><?php echo form_error('nama');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="profesi" class="control-label"><span class="text-danger">*</span>Profesi</label>
						<div class="form-group">
							<input type="text" name="profesi" value="<?php echo ($this->input->post('profesi') ? $this->input->post('profesi') : $testi['profesi']); ?>" class="form-control" id="profesi" />
							<span class="text-danger"><?php echo form_error('profesi');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="testimoni" class="control-label"><span class="text-danger">*</span>Testimoni</label>
						<div class="form-group">
							<textarea name="testimoni" class="form-control" id="testimoni"><?php echo ($this->input->post('testimoni') ? $this->input->post('testimoni') : $testi['testimoni']); ?></textarea>
							<span class="text-danger"><?php echo form_error('testimoni');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Save
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>