<!DOCTYPE html>
<html lang="en">
<head>
<title>NOKIA</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Zeta Template Project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/styles/bootstrap4/bootstrap.min.css">
<link href="<?php echo base_url(); ?>assets/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/styles/responsive.css">
</head>

<body>

<div class="super_container">
	
	<!-- Header -->

	<header class="header d-flex flex-row justify-content-end align-items-center">

		<!-- Logo -->
		<div class="logo_container mr-auto">
			<div class="logo">
				<a href="#"><span>n</span>nokia<span>.</span></a>
			</div>
		</div>

		<!-- Main Navigation -->
		<nav class="main_nav justify-self-end">
			<ul class="nav_items">
				<li class="active"><a href="#"><span>home</span></a></li>
				<li><a href="services.html"><span>services</span></a></li>
				<li><a href="elements.html"><span>elements</span></a></li>
				<li><a href="blog.html"><span>blog</span></a></li>
				<li><a href="contact.html"><span>contact</span></a></li>
			</ul>
		</nav>

		<!-- Hamburger -->
		<div class="hamburger_container">
			<span class="hamburger_text">Menu</span>
			<span class="hamburger_icon"></span>
		</div>

	</header>

	<!-- Menu -->

	<div class="fs_menu_overlay"></div>
	<div class="fs_menu_container">
		<div class="fs_menu_shapes"><img src="<?php echo base_url(); ?>assets/<?php echo base_url(); ?>assets/images/menu_shapes.png" alt=""></div>
		<nav class="fs_menu_nav">
			<ul class="fs_menu_list">
				<li><a href="#"><span><span>H</span>Home</span></a></li>
				<li><a href="#"><span><span>S</span>Services</span></a></li>
				<li><a href="#"><span><span>E</span>Elements</span></a></li>
				<li><a href="#"><span><span>B</span>Blog</span></a></li>
				<li><a href="#"><span><span>C</span>Contact</span></a></li>
			</ul>
		</nav>
		<div class="fs_social_container d-flex flex-row justify-content-end align-items-center">
			<ul class="fs_social">
				<li><a href="#"><i class="fab fa-pinterest trans_300"></i></a></li>
				<li><a href="#"><i class="fab fa-facebook-f trans_300"></i></a></li>
				<li><a href="#"><i class="fab fa-twitter trans_300"></i></a></li>
				<li><a href="#"><i class="fab fa-dribbble trans_300"></i></a></li>
				<li><a href="#"><i class="fab fa-behance trans_300"></i></a></li>
				<li><a href="#"><i class="fab fa-linkedin-in trans_300"></i></a></li>
			</ul>
		</div>
	</div>

	<!-- Hero Slider -->
	
	<div class="home">
		<div class="hero_slider_container slider_prlx">
			<div class="owl-carousel owl-theme hero_slider">

				<!-- Slider Item -->
				<div class="owl-item main_slider_item">
					<div class="main_slider_item_bg" style="background-image:url(<?php echo base_url(); ?>assets/images/mainslider1.jpg)"></div>
					<div class="container">
						<div class="row">
							<div class="col slider_content_col">
								<div class="main_slider_content">
									<h1>Nokia - HMD Global</h1>
									<h2>Bukan <span>brand </span>biasa.</h2>
									<p>Nokia yang kini berada di bawah bendera HMD Global adalah pabrikan smartphone yang pernah populer di pasar Indonesia. Saat belum ada campur tangan HMD Global, merek Nokia begitu populer di pasar global dan itu terjadi di awal tahun 2000-an. </p>
									<div class="button discover_button">
										<a href="#" class="d-flex flex-row align-items-center justify-content-center">kenalan<img src="<?php echo base_url(); ?>assets/images/arrow_right.svg" alt=""></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Slider Item -->
				<div class="owl-item main_slider_item">
					<div class="main_slider_item_bg" style="background-image:url(<?php echo base_url(); ?>assets/images/mainslider2.jpg)"></div>
					<div class="main_slider_shapes"><img src="<?php echo base_url(); ?>assets/images/main_slider_shapes.png" alt="" style="width: 100% !important;"></div>
					<div class="container">
						<div class="row">
							<div class="col slider_content_col">
								<div class="main_slider_content">
									<h1>Nokia - HMD Global</h1>
									<h2>pergi <span>untuk </span>kembali.</h2>
									<p>Smartphone pertama yang digarap Nokia bersama Microsoft adalah Nokia Lumia 800 dengan sistem operasi Windows Phone. Terus memproduksi banyak perangkat, smartphone Nokia bersama Microsoft akhirnya harus kalah dengan smartphone berbasiskan Android. </p>
									<div class="button discover_button">
										<a href="#" class="d-flex flex-row align-items-center justify-content-center">perkenalan<img src="<?php echo base_url(); ?>assets/images/arrow_right.svg" alt=""></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Slider Item -->
				<div class="owl-item main_slider_item">
					<div class="main_slider_item_bg" style="background-image:url(<?php echo base_url(); ?>assets/images/mainslider3.jpg)"></div>
					<div class="main_slider_shapes"><img src="<?php echo base_url(); ?>assets/images/main_slider_shapes.png" alt="" style="width: 100% !important;"></div>
					<div class="container">
						<div class="row">
							<div class="col slider_content_col">
								<div class="main_slider_content">
									<h1>Nokia - HMD Global</h1>
									<h2>Comeback <span>is </span>Real.</h2>
									<p>Kini, Nokia bersama HMD Global begitu getol untuk menghadirkan smartphone berbasis Android. Hal ini pun mereka perlihatkan saat hadir di ajang MWC 2018, dimana mereka merilis empat smartphone, yakni Nokia 8 Sirocco, Nokia 7 Plus, Nokia 6 (2018), dan Nokia 1. </p>
									<div class="button discover_button">
										<a href="#" class="d-flex flex-row align-items-center justify-content-center">kenalan kuy<img src="<?php echo base_url(); ?>assets/images/arrow_right.svg" alt=""></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- Slider Dots -->

			<div class="main_slider_dots">
				<div class="container">
					<div class="row">
						<div class="col">
							<ul id="main_slider_custom_dots" class="main_slider_custom_dots">
								<li class="main_slider_custom_dot active">01.</li>
								<li class="main_slider_custom_dot">02.</li>
								<li class="main_slider_custom_dot">03.</li>
							</ul>
						</div>
					</div>
				</div>		
			</div>

			<!-- Slider Dots -->

			<div class="main_slider_nav_left main_slider_nav">
				<i class="fas fa-chevron-left trans_300"></i>
			</div>

			<div class="main_slider_nav_right main_slider_nav">
				<i class="fas fa-chevron-right trans_300"></i>
			</div>

		</div>
	</div>

	<div class="home_social_container d-flex flex-row justify-content-end align-items-center">
		<ul class="home_social">
			<li><a href="#"><i class="fab fa-pinterest trans_300"></i></a></li>
			<li><a href="#"><i class="fab fa-facebook-f trans_300"></i></a></li>
			<li><a href="#"><i class="fab fa-twitter trans_300"></i></a></li>
			<li><a href="#"><i class="fab fa-dribbble trans_300"></i></a></li>
			<li><a href="#"><i class="fab fa-behance trans_300"></i></a></li>
			<li><a href="#"><i class="fab fa-linkedin-in trans_300"></i></a></li>
		</ul>
	</div>
		
	<!-- Features -->

	<!-- About -->

	<div class="about prlx_parent">
		<!-- https://unsplash.com/@nativemello -->
		<div class="about_background prlx" style="background-image:url(<?php echo base_url(); ?>assets/images/aboutme.jpg)"></div>
		<div class="about_shapes"><img src="<?php echo base_url(); ?>assets/images/about_shapes.png" alt=""></div>

		<div class="container">
			<div class="row">
				<div class="col-lg-6 offset-lg-3 text-center section_title">
					<h2>tentang nokia<span>hmd</span></h2>
				</div>
			</div>
			<div class="row">

				<div class="col-lg-6">
					<div class="about_text">
						<p>Sudah sekitar setahun, Nokia melalui HMD Global mulai bangkit kembali di pasar smartphone dengan Android. Perjalanan mereka tentu masih panjang untuk kembali ke masa jayanya dulu. Di Indonesia sendiri HMD Global telah meluncurkan lima model smartphone yakni Nokia 3, Nokia 5, Nokia 6, Nokia 2, dan Nokia 8. </p>
						<img src="<?php echo base_url(); ?>assets/images/signiture.png" alt="">
					</div>
				</div>

				<!-- Data Percentage -->

				</div>

			</div>
		</div>
		
	</div>

	<!-- Testimonials -->

	<div class="testimonials">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 offset-lg-3 text-center section_title section_title_dark">
					<h2>Testimonial<span>nokia</span></h2>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-10 offset-lg-1">
					<div class="testimonials_container">
						<div class="testimonials_container_inner"></div>

						<!-- Testimonials Slider -->

						<div class="owl-carousel owl-theme testimonials_slider">

							<!-- Testimonials Item -->
							<div class="owl-item testimonials_item d-flex flex-column align-items-center justify-content-center text-center">
								<div class="testimonials_content">
									<?php foreach($testi as $t){ ?>


									<div class="test_name"><?php echo $t['nama']; ?></div>
									<div class="test_title"><?php echo $t['profesi']; ?></div>
									<div class="test_quote">"</div>
									<p><?php echo $t['testimoni']; ?> </p>

									<?php } ?>
								</div>
							</div>

							<!-- Testimonials Item -->

							<!-- Testimonials Item -->
							
							</div>
						</div>

					</div>
				</div>

				<!-- Testimonials Slider Navigation -->

	<!-- Services -->

	<!-- Clients -->

	<!-- Contact -->

	<div class="contact prlx_parent">
		<!-- <div class="contact_background parallax-window" data-parallax="scroll" data-speed="0.7" data-image-src="images/contact_background.jpg"></div> -->
		<div class="contact_background prlx" style="background-image: url(<?php echo base_url(); ?>assets/images/contactbackground.jpg);"></div>
		<div class="contact_shapes"><img src="<?php echo base_url(); ?>assets/images/contact_shape.png" alt=""></div>
		<div class="container">
			
			<div class="row">
				<div class="col-lg-6 offset-lg-3 text-center section_title contact_title">
					<h2>HMD Global<span>nokia</span></h2>
				</div>
			</div>
			
			<div class="row">
				<div class="col-lg-10 offset-lg-1 text-center contact_text">
					<p>HMD Global adalah perusahaan Finlandia yang berafiliasi dengan Nokia. Sejak beroperasi mulai Desember 2016, perusahaan ini mengembangkan sekaligus memasarkan perangkat telepon seluler dan telepon pintar dengan merek "Nokia" melalui kesepakatan lisensi.</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			<div class="row footer_content d-flex flex-sm-row flex-column align-items-center">
				<div class="col-sm-6 cr text-sm-left text-center">
					<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
				</div>
				<div class="col-sm-6 text-sm-right text-center">
					<div class="footer_social_container">
						<ul class="footer_social">
							<li><a href="#"><i class="fab fa-pinterest trans_300"></i></a></li>
							<li><a href="#"><i class="fab fa-facebook-f trans_300"></i></a></li>
							<li><a href="#"><i class="fab fa-twitter trans_300"></i></a></li>
							<li><a href="#"><i class="fab fa-dribbble trans_300"></i></a></li>
							<li><a href="#"><i class="fab fa-behance trans_300"></i></a></li>
							<li><a href="#"><i class="fab fa-linkedin-in trans_300"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</footer>

</div>

<script src="<?php echo base_url(); ?>assets/js/jquery-3.2.1.min.js"></script>
<script src="<?php echo base_url(); ?>assets/styles/bootstrap4/popper.js"></script>
<script src="<?php echo base_url(); ?>assets/styles/bootstrap4/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/TweenMax.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/TimelineMax.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/animation.gsap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/progressbar/progressbar.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/easing/easing.js"></script>
<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
</body>

</html>